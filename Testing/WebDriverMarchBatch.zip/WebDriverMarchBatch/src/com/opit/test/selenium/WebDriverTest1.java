package com.opit.test.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebDriverTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Polymorphic instantiation
		//WebDriver is an interface
		//WebDriver driver = new FirefoxDriver();
		
		//Working with Firefox Driver
		//System.setProperty("webdriver.chrome.driver", "C:\\jars\\chromedriver_win32\\chromedriver.exe");
		//WebDriver chromeDriver = new ChromeDriver();
		
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.southwest.com");
		
		WebElement textDeparture = driver.findElement(By.id("air-city-departure"));
		textDeparture.sendKeys("SFO");
	
		
		driver.close();
	}

}
