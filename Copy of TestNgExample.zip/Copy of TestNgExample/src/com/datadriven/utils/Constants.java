package com.datadriven.utils;

public class Constants {
	public static final String URL = "http://www.expedia.com";
    public static final String File_Path = "Users//shruti//Documents//workspace//SeleniumDataDriven//resources//ExcelData.xlsx//";
    public static final String File_Name = "ExcelData.xlsx";
}
