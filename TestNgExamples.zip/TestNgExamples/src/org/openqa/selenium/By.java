//package org.openqa.selenium;
//
//public class By {
//
//	public static By tagName(String string) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public static By linkText(String depDate1) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public static By id(String string) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public static By xpath(String string) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//}
